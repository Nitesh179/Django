lst=[0.0,0,0,0]

res = all( [True, False])

print(res)
