from django.contrib import admin
from Xmen.models import Contact
from Xmen.models import Customer

# Register your models here.

admin.site.register(Contact)

admin.site.register(Customer)