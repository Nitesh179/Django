from django.apps import AppConfig


class XmenConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Xmen'
